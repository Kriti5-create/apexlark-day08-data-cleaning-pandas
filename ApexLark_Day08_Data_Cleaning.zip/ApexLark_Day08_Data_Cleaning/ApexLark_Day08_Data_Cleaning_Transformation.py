# %% [markdown]
# # Apex Lark – Day 08: Advanced Data Cleaning & Data Transformation Using Pandas
#
# **Author:** Kriti Ahlawat  |  **Program:** ApexLark Data Analytics Internship
# **Tools:** Python, Pandas, NumPy, Matplotlib
# **Dataset:** Sample Superstore retail sales (`data/superstore_sales_input.csv`), 9,993 order lines, Jan 2014 – Dec 2017
#
# **Business scenario:** a retail company receives daily sales data from several branches. Before it can be used for reporting, it must be
# profiled, cleaned, transformed into a standard format and analysed.
#
# | # | Section |
# |---|---|
# | 1 | Setup & configuration |
# | 2 | Load the dataset |
# | 3 | Data quality assessment |
# | 4 | Data cleaning |
# | 5 | Data transformation (new business columns) |
# | 6 | Exploratory data analysis |
# | 7 | Data visualization |
# | 8 | Save outputs & business insights |

# %% [markdown]
# ## 1. Setup & configuration

# %%
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

try:                       # `display` exists in Jupyter; fall back to print in a plain script
    display
except NameError:
    display = print

# ---- Paths -----------------------------------------------------------------
RAW_PATH = Path("data/superstore_sales_input.csv")
CLEAN_PATH = Path("data/superstore_sales_day08_cleaned.csv")
CHART_DIR = Path("charts")
OUTPUT_DIR = Path("outputs")
CHART_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

# ---- Business rules (change here, everything else follows) -----------------
HIGH_MARGIN_PCT = 30      # profit margin >= 30%         -> "High"
MEDIUM_MARGIN_PCT = 10    # 10% <= margin < 30%          -> "Medium"; below 10% (incl. losses) -> "Low"
KEY_COLUMNS = ["order_id", "product_id"]   # rows missing these cannot be repaired

pd.set_option("display.max_columns", 30)
pd.set_option("display.width", 170)
pd.set_option("display.max_colwidth", 50)
pd.set_option("display.float_format", "{:,.2f}".format)

PRIMARY, ACCENT, GREY = "#2F5597", "#ED7D31", "#7F7F7F"
plt.rcParams.update({"figure.dpi": 110, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": 0.3, "axes.titleweight": "bold", "axes.titlesize": 13})

money = FuncFormatter(lambda v, _: f"${v/1e6:.1f}M" if abs(v) >= 1e6 else f"${v/1e3:.0f}K" if abs(v) >= 1e3 else f"${v:.0f}")

_NEW_CHARTS = []           # (used by the notebook builder to embed saved charts)


def save_chart(fig, filename):
    """Save a figure to charts/ and close it."""
    path = CHART_DIR / filename
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    _NEW_CHARTS.append(str(path))
    print(f"saved {path}")

# %% [markdown]
# ## 2. Load the dataset

# %%
raw = pd.read_csv(RAW_PATH)
print("First 10 records")
display(raw.head(10))

# %%
print("Last 10 records")
display(raw.tail(10))

# %%
print("Dataset information (info):")
raw.info()

# %%
print("Descriptive statistics (describe):")
display(raw.describe().T)

# %%
print(f"Rows: {raw.shape[0]:,}   Columns: {raw.shape[1]}")

# %% [markdown]
# ## 3. Data quality assessment
#
# Every check below is written to run on *any* export of this dataset, so the same notebook can be re-run on a fresh, messier branch file.

# %%
def missing_value_report(df):
    """Null count and null percentage per column."""
    report = pd.DataFrame({"missing_count": df.isna().sum(), "null_percent": (df.isna().mean() * 100).round(2)})
    report["dtype"] = df.dtypes.astype(str)
    return report


missing_report = missing_value_report(raw)
display(missing_report)

# %%
# Duplicates: exact duplicate rows, and duplicates ignoring the Row ID counter
exact_dupes = int(raw.duplicated().sum())
dupes_ignoring_row_id = int(raw.drop(columns=["Row ID"]).duplicated().sum())
print(f"Exact duplicate rows:              {exact_dupes}")
print(f"Duplicates ignoring 'Row ID':      {dupes_ignoring_row_id}")

# Incorrect data types: date columns stored as text
print("\nColumn data types (dates should be datetime, not text):")
display(raw.dtypes.astype(str).rename("dtype").to_frame())

# %%
# Unique values in categorical columns
categorical_cols = ["Ship Mode", "Segment", "Country", "Region", "Category", "Sub-Category"]
for col in categorical_cols:
    print(f"{col} ({raw[col].nunique()}): {sorted(raw[col].dropna().unique())}")
print(f"\nCity: {raw['City'].nunique()} unique | State: {raw['State'].nunique()} unique | Product ID: {raw['Product ID'].nunique()} unique | Customer ID: {raw['Customer ID'].nunique()} unique")

# %%
def run_validity_checks(df):
    """Count invalid / inconsistent entries and return them as a table."""
    text_cols = df.select_dtypes(include=["object", "string"]).columns
    od, sd = pd.to_datetime(df["Order Date"], errors="coerce"), pd.to_datetime(df["Ship Date"], errors="coerce")
    order_year = pd.to_numeric(df["Order ID"].str.extract(r"-(\d{4})-")[0], errors="coerce")
    names_per_id = df.groupby("Product ID")["Product Name"].nunique()

    checks = {
        "Text with leading/trailing/double spaces": int(sum((df[c].dropna() != df[c].dropna().str.replace(r"\s+", " ", regex=True).str.strip()).sum() for c in text_cols)),
        "Non-breaking spaces (hidden \\xa0 characters) in text": int(sum(df[c].dropna().str.contains("\u00a0", regex=False).sum() for c in text_cols)),
        "Inconsistent text case in categorical columns": int(sum(df[c].nunique() - df[c].str.strip().str.title().nunique() for c in categorical_cols)),
        "Unparseable dates": int(od.isna().sum() + sd.isna().sum()),
        "Sales <= 0": int((df["Sales"] <= 0).sum()),
        "Quantity <= 0": int((df["Quantity"] <= 0).sum()),
        "Discount outside 0-100%": int(((df["Discount"] < 0) | (df["Discount"] > 1)).sum()),
        "Profit greater than Sales": int((df["Profit"] > df["Sales"]).sum()),
        "Ship Date before Order Date": int((sd < od).sum()),
        "Order ID year differs from Order Date year": int((order_year != od.dt.year).sum()),
        "Product IDs used for 2+ product names": int((names_per_id > 1).sum()),
        "Columns with no analytical value (single value / pure row counter)": int(df["Country"].nunique() == 1) + int(df["Row ID"].is_unique),
    }
    return checks


validity = run_validity_checks(raw)
display(pd.Series(validity, name="rows_or_ids_affected").to_frame())

# %% [markdown]
# ### 3.1 Data quality issue summary table

# %%
def build_issue_summary(missing, exact, dupes_wo_id, validity):
    """One table of every issue found, with the planned fix."""
    fixes = {
        "Text with leading/trailing/double spaces": "str.strip() and collapse repeated spaces",
        "Non-breaking spaces (hidden \\xa0 characters) in text": "Replace \\xa0 with a normal space (not delete, or words would merge)",
        "Inconsistent text case in categorical columns": "Standardise to Title Case",
        "Unparseable dates": "pd.to_datetime(errors='coerce'), then investigate",
        "Sales <= 0": "Drop rows (invalid transaction)",
        "Quantity <= 0": "Drop rows (invalid transaction)",
        "Discount outside 0-100%": "Clip to the 0-1 range",
        "Profit greater than Sales": "Flag for review (impossible)",
        "Ship Date before Order Date": "Set ship date to NaT",
        "Order ID year differs from Order Date year": "Keep; order IDs are issued by a different system (documented)",
        "Product IDs used for 2+ product names": "Keep; names are valid product variants (documented)",
        "Columns with no analytical value (single value / pure row counter)": "Drop 'Country' (always United States) and 'Row ID'",
    }
    rows = [("Missing values", int(missing["missing_count"].sum()), "Median (numeric) / mode (text) / drop if key missing"),
            ("Exact duplicate rows", exact, "drop_duplicates()"),
            ("Duplicates ignoring Row ID", dupes_wo_id, "drop_duplicates(subset=all but Row ID)"),
            ("Incorrect data types (Order Date, Ship Date stored as text)", 2, "Convert to datetime64")]
    rows += [(k, v, fixes[k]) for k, v in validity.items()]
    out = pd.DataFrame(rows, columns=["data_quality_issue", "records_affected", "cleaning_action"])
    out["status"] = np.where(out["records_affected"] > 0, "Issue found", "OK")
    return out


issue_summary = build_issue_summary(missing_report, exact_dupes, dupes_ignoring_row_id, validity)
issue_summary.to_csv(OUTPUT_DIR / "data_quality_issue_summary.csv", index=False)
display(issue_summary)

# %% [markdown]
# ## 4. Data cleaning
#
# All steps live in one function, `clean_sales_data()`, so the process is reproducible: raw CSV in, cleaned DataFrame out.

# %%
def to_snake_case(name):
    """'Sub-Category' -> 'sub_category'"""
    return name.strip().lower().replace("-", "_").replace(" ", "_")


def clean_sales_data(df):
    """Clean the raw sales data and return (cleaned_df, log_of_actions)."""
    df, log = df.copy(), []

    # 1. Consistent column names
    df.columns = [to_snake_case(c) for c in df.columns]
    log.append(("Renamed columns to snake_case", len(df.columns)))

    # 2. Remove extra spaces and unwanted (non-printable / odd) characters from text
    text_cols = df.select_dtypes(include=["object", "string"]).columns
    changed = 0
    for col in text_cols:
        before = df[col].copy()
        df[col] = (df[col].str.replace("\u00a0", " ", regex=False)               # non-breaking space -> normal space
                          .str.replace(r"[\x00-\x1f\x7f\u200b]", "", regex=True)   # control / zero-width characters
                          .str.replace(r"\s+", " ", regex=True).str.strip())
        changed += int((before.fillna("") != df[col].fillna("")).sum())
    log.append(("Trimmed spaces / removed unwanted characters (cells changed)", changed))

    # 3. Standardise text case: IDs upper, names title (product names keep their original brand casing)
    for col in ["order_id", "customer_id", "product_id"]:
        df[col] = df[col].str.upper()
    for col in ["ship_mode", "segment", "country", "region", "category", "sub_category", "city", "state"]:
        df[col] = df[col].str.title()
    log.append(("Standardised text case (IDs upper, categories/places title)", 11))

    # 4. Correct data types
    for col in ["order_date", "ship_date"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    for col in ["sales", "discount", "profit"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
    for col in ["ship_mode", "segment", "region", "category", "sub_category"]:
        df[col] = df[col].astype("category")
    log.append(("Converted data types (dates -> datetime, text -> category)", 9))

    # 5. Replace invalid values
    bad_ship = df["ship_date"] < df["order_date"]
    df.loc[bad_ship, "ship_date"] = pd.NaT
    n_discount = int(((df["discount"] < 0) | (df["discount"] > 1)).sum())
    df["discount"] = df["discount"].clip(0, 1)
    log.append(("Invalid ship dates set to NaT", int(bad_ship.sum())))
    log.append(("Discounts clipped to 0-1", n_discount))

    # 6. Missing values: drop rows missing a key, impute the rest
    n_before = len(df)
    df = df.dropna(subset=KEY_COLUMNS + ["order_date"])
    log.append(("Rows dropped for missing key fields", n_before - len(df)))
    imputed = 0
    for col in df.select_dtypes(include="number").columns:
        n = int(df[col].isna().sum())
        if n:
            df[col] = df[col].fillna(df[col].median())
            imputed += n
    for col in df.select_dtypes(include=["object", "string", "category"]).columns:
        n = int(df[col].isna().sum())
        if n:
            df[col] = df[col].fillna(df[col].mode().iloc[0])
            imputed += n
    log.append(("Missing values imputed (median / mode)", imputed))

    # 7. Remove invalid transactions
    n_before = len(df)
    df = df[(df["sales"] > 0) & (df["quantity"] > 0)]
    log.append(("Rows dropped for Sales <= 0 or Quantity <= 0", n_before - len(df)))

    # 8. Remove duplicates (ignoring the Row ID counter, which is the only column that differs)
    n_before = len(df)
    df = df.drop_duplicates(subset=[c for c in df.columns if c != "row_id"])
    log.append(("Duplicate rows removed", n_before - len(df)))

    # 9. Remove unnecessary columns
    df = df.drop(columns=["row_id", "country"])
    log.append(("Unnecessary columns removed (row_id, country)", 2))

    return df.reset_index(drop=True), pd.DataFrame(log, columns=["cleaning_step", "records_affected"])


clean, cleaning_log = clean_sales_data(raw)
cleaning_log.to_csv(OUTPUT_DIR / "cleaning_log.csv", index=False)
display(cleaning_log)
print(f"\nShape before: {raw.shape}   after: {clean.shape}")

# %%
print("Cleaned data types:")
display(clean.dtypes.astype(str).rename("dtype").to_frame())
print("Remaining missing values:", int(clean.isna().sum().sum()))

# %% [markdown]
# ## 5. Data transformation
#
# The dataset has **no unit-price column**, so the list price is derived from the recorded sale:
# `unit_price = sales / (quantity × (1 − discount))`. The `sales` column in the source is already the *discounted* amount, so:
#
# * `total_sales` = quantity × unit_price (gross, before discount)
# * `discount_amount` = total_sales × discount
# * `net_sales` = total_sales − discount_amount (this equals the original `sales`, which is checked below)

# %%
def add_business_columns(df):
    """Create the derived business metrics."""
    df = df.copy()
    df["unit_price"] = (df["sales"] / (df["quantity"] * (1 - df["discount"]))).round(4)
    df["total_sales"] = df["quantity"] * df["unit_price"]
    df["discount_amount"] = df["total_sales"] * df["discount"]
    df["net_sales"] = df["total_sales"] - df["discount_amount"]
    df["profit_margin_pct"] = (df["profit"] / df["net_sales"] * 100).round(2)
    df["order_year"] = df["order_date"].dt.year
    df["order_month"] = df["order_date"].dt.month
    df["order_month_name"] = df["order_date"].dt.month_name()
    df["profit_category"] = np.select(
        [df["profit_margin_pct"] >= HIGH_MARGIN_PCT, df["profit_margin_pct"] >= MEDIUM_MARGIN_PCT],
        ["High", "Medium"], default="Low")
    return df


df = add_business_columns(clean)
assert np.allclose(df["net_sales"], df["sales"], atol=0.01), "net_sales should reproduce the source sales column"
print("Check passed: net_sales equals the original discounted sales amount.")
display(df[["order_id", "quantity", "unit_price", "total_sales", "discount", "discount_amount", "net_sales",
            "profit", "profit_margin_pct", "order_year", "order_month", "profit_category"]].head(10))

# %%
print("Profit category rules: High >= %d%% | Medium %d%% to <%d%% | Low < %d%% (includes loss-making lines)" %
      (HIGH_MARGIN_PCT, MEDIUM_MARGIN_PCT, HIGH_MARGIN_PCT, MEDIUM_MARGIN_PCT))
cat_counts = df["profit_category"].value_counts().reindex(["High", "Medium", "Low"])
display(pd.DataFrame({"order_lines": cat_counts, "share_pct": (cat_counts / len(df) * 100).round(1)}))

# %% [markdown]
# ## 6. Exploratory data analysis
# *Sales* in this section means **net sales** (after discount), the actual revenue.

# %%
top10_products = df.groupby("product_name")["net_sales"].sum().nlargest(10).round(2)
top10_customers = df.groupby(["customer_id"])["net_sales"].sum().nlargest(10).round(2)
region_sales = df.groupby("region", observed=True)["net_sales"].sum().sort_values(ascending=False).round(2)
category_profit = df.groupby("category", observed=True).agg(net_sales=("net_sales", "sum"), profit=("profit", "sum")).round(2)
category_profit["margin_pct"] = (category_profit["profit"] / category_profit["net_sales"] * 100).round(2)
category_profit = category_profit.sort_values("profit", ascending=False)
monthly = df.groupby(df["order_date"].dt.to_period("M"))["net_sales"].sum()
monthly.index = monthly.index.to_timestamp()
aov = df.groupby("order_id")["net_sales"].sum()

print("Top 10 products by sales:");   display(top10_products)
print("Top 10 customers by revenue:"); display(top10_customers)

# %%
print("Region-wise sales:");  display(region_sales)
print("Category-wise profit:"); display(category_profit)

# %%
yearly = df.groupby("order_year").agg(net_sales=("net_sales", "sum"), profit=("profit", "sum"), orders=("order_id", "nunique"))
yearly["yoy_growth_pct"] = (yearly["net_sales"].pct_change() * 100).round(1)
print("Yearly trend:"); display(yearly.round(2))
month_of_year = df.groupby("order_month")["net_sales"].sum()
print(f"Best calendar month: {month_of_year.idxmax()} (${month_of_year.max():,.0f}) | weakest: {month_of_year.idxmin()} (${month_of_year.min():,.0f})")
print(f"Peak month overall: {monthly.idxmax():%b %Y} (${monthly.max():,.0f})")
print(f"\nAverage order value: ${aov.mean():,.2f} (median ${aov.median():,.2f}) across {aov.size:,} orders")

disc = df.assign(discount_band=pd.cut(df["discount"], [-0.01, 0, 0.2, 0.5, 1], labels=["None", "1-20%", "21-50%", ">50%"]))
discount_profit = disc.groupby("discount_band", observed=True).agg(lines=("profit", "size"), profit=("profit", "sum"), margin_pct=("profit_margin_pct", "mean")).round(2)
print("\nProfit by discount band:"); display(discount_profit)

# %% [markdown]
# ## 7. Data visualization

# %%
# Chart 1 - Monthly sales trend (line)
fig, ax = plt.subplots(figsize=(10, 4.8))
ax.plot(monthly.index, monthly.values, color=PRIMARY, marker="o", markersize=3.5, label="Monthly net sales")
ax.plot(monthly.index, monthly.rolling(3).mean(), color=ACCENT, linewidth=2, label="3-month moving average")
ax.set_title("Monthly Sales Trend (2014-2017)")
ax.set_xlabel("Order Month"); ax.set_ylabel("Net Sales (USD)")
ax.yaxis.set_major_formatter(money); ax.legend()
save_chart(fig, "01_monthly_sales_trend.png")

# %%
# Chart 2 - Sales by region (bar)
fig, ax = plt.subplots(figsize=(7.5, 4.8))
bars = ax.bar(region_sales.index, region_sales.values, color=[PRIMARY if r == region_sales.idxmax() else GREY for r in region_sales.index])
ax.bar_label(bars, labels=[f"${v/1e3:,.0f}K" for v in region_sales.values], padding=3)
ax.set_title("Sales by Region"); ax.set_xlabel("Region"); ax.set_ylabel("Net Sales (USD)")
ax.yaxis.set_major_formatter(money); ax.set_ylim(0, region_sales.max() * 1.12)
ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=PRIMARY), plt.Rectangle((0, 0), 1, 1, color=GREY)], labels=["Highest region", "Other regions"])
save_chart(fig, "02_sales_by_region.png")

# %%
# Chart 3 - Profit by category (bar)
fig, ax = plt.subplots(figsize=(7.5, 4.8))
bars = ax.bar(category_profit.index, category_profit["profit"], color=[PRIMARY if c == category_profit.index[0] else GREY for c in category_profit.index])
ax.bar_label(bars, labels=[f"${v/1e3:,.0f}K ({m:.1f}%)" for v, m in zip(category_profit["profit"], category_profit["margin_pct"])], padding=3)
ax.set_title("Profit by Category"); ax.set_xlabel("Product Category"); ax.set_ylabel("Total Profit (USD)")
ax.yaxis.set_major_formatter(money); ax.set_ylim(0, category_profit["profit"].max() * 1.15)
ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=PRIMARY), plt.Rectangle((0, 0), 1, 1, color=GREY)], labels=["Most profitable", "Other categories"])
save_chart(fig, "03_profit_by_category.png")

# %%
# Chart 4 - Top 10 products by sales (horizontal bar)
fig, ax = plt.subplots(figsize=(10, 5.5))
labels = [n if len(n) <= 48 else n[:45] + "..." for n in top10_products.index]
ax.barh(labels[::-1], top10_products.values[::-1], color=PRIMARY, label="Net sales")
for y, v in enumerate(top10_products.values[::-1]):
    ax.text(v + top10_products.max() * 0.01, y, f"${v/1e3:,.1f}K", va="center", fontsize=9)
ax.set_title("Top 10 Products by Sales"); ax.set_xlabel("Net Sales (USD)"); ax.set_ylabel("Product")
ax.xaxis.set_major_formatter(money); ax.set_xlim(0, top10_products.max() * 1.13); ax.legend(loc="lower right")
save_chart(fig, "04_top10_products.png")

# %%
# Chart 5 - Distribution of sales (histogram, log-spaced bins because sales are heavily right-skewed)
fig, ax = plt.subplots(figsize=(9, 4.8))
ax.hist(df["net_sales"], bins=np.logspace(np.log10(df["net_sales"].min()), np.log10(df["net_sales"].max()), 40), color=PRIMARY, edgecolor="white")
ax.axvline(df["net_sales"].median(), color=ACCENT, linestyle="--", linewidth=2, label=f"Median ${df['net_sales'].median():,.0f}")
ax.axvline(df["net_sales"].mean(), color="#C00000", linestyle="--", linewidth=2, label=f"Mean ${df['net_sales'].mean():,.0f}")
ax.set_xscale("log")
ax.set_title("Distribution of Sales per Order Line"); ax.set_xlabel("Net Sales per Line (USD, log scale)"); ax.set_ylabel("Number of Order Lines")
ax.legend()
save_chart(fig, "05_sales_distribution.png")

# %% [markdown]
# ## 8. Save outputs & business insights

# %%
df.to_csv(CLEAN_PATH, index=False)
region_sales.to_csv(OUTPUT_DIR / "sales_by_region.csv")
category_profit.to_csv(OUTPUT_DIR / "profit_by_category.csv")
top10_products.to_csv(OUTPUT_DIR / "top10_products.csv")
top10_customers.to_csv(OUTPUT_DIR / "top10_customers.csv")
monthly.rename("net_sales").to_csv(OUTPUT_DIR / "monthly_sales.csv")
yearly.to_csv(OUTPUT_DIR / "yearly_summary.csv")
discount_profit.to_csv(OUTPUT_DIR / "profit_by_discount_band.csv")
print(f"Cleaned dataset saved: {CLEAN_PATH}  ({df.shape[0]:,} rows x {df.shape[1]} columns)")

# %%
total_net, total_profit = df["net_sales"].sum(), df["profit"].sum()
subcat_profit = df.groupby("sub_category", observed=True)["profit"].sum().sort_values()
loss_lines = df[df["profit"] < 0]
print(f"Total net sales ${total_net:,.0f} | profit ${total_profit:,.0f} | margin {total_profit/total_net*100:.1f}%")
print(f"Highest-revenue region: {region_sales.idxmax()} (${region_sales.max():,.0f})")
print(f"Most profitable category: {category_profit.index[0]} (${category_profit['profit'].iloc[0]:,.0f}, {category_profit['margin_pct'].iloc[0]:.1f}% margin)")
print(f"Loss-making lines: {len(loss_lines):,} ({len(loss_lines)/len(df)*100:.1f}%), total loss ${loss_lines['profit'].sum():,.0f}")
print(f"Worst sub-categories by profit: {subcat_profit.head(3).round(0).to_dict()}")
print(f"Lowest-margin region: {(df.groupby('region', observed=True)['profit'].sum()/region_sales).idxmin()}")
print(f"Top 10 customers share of revenue: {top10_customers.sum()/total_net*100:.1f}%")
INSIGHT_FACTS = dict(total_net=total_net, total_profit=total_profit)

# %% [markdown]
# ### Business insights
# See `ApexLark_Day08_Business_Analysis_Report.pdf` for the one-page report with the data quality findings, key results and five recommendations.
