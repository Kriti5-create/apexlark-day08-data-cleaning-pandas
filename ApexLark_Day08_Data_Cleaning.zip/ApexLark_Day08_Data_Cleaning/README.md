# Apex Lark – Day 08: Advanced Data Cleaning & Data Transformation Using Pandas

**Author:** Kriti Ahlawat · **Program:** ApexLark Data Analytics Internship · **Tools:** Python, Pandas, NumPy, Matplotlib, Jupyter

A reproducible Pandas pipeline that profiles, cleans, transforms and analyses the Sample Superstore retail sales data (9,993 order lines, 2014–2017).

![Monthly sales trend](charts/01_monthly_sales_trend.png)

## Repository contents

| File / Folder | Description |
|---|---|
| `ApexLark_Day08_Data_Cleaning_Transformation.ipynb` | Main notebook, saved with outputs |
| `ApexLark_Day08_Data_Cleaning_Transformation.py` | Same code as a plain script |
| `ApexLark_Day08_Business_Analysis_Report.pdf` | One-page business analysis report |
| `data/superstore_sales_input.csv` | Input dataset (19 columns) |
| `data/superstore_sales_day08_cleaned.csv` | **Cleaned & transformed dataset** (26 columns) |
| `charts/` | 5 required charts (PNG) |
| `outputs/` | Data quality summary, cleaning log and EDA tables (CSV) |
| `requirements.txt` | Python libraries |

## How to run
```bash
pip install -r requirements.txt
python ApexLark_Day08_Data_Cleaning_Transformation.py      # or open the notebook and Run All
```
Run from the repository folder so the relative paths work.

## Task coverage
| # | Requirement | Notebook section |
|---|---|---|
| 1 | Load: head/tail 10, `info()`, `describe()`, shape | 2 |
| 2 | Quality assessment: nulls %, duplicates, dtypes, categorical values, invalid entries, issue summary table | 3 |
| 3 | Cleaning: duplicates, unneeded columns, missing values, dtypes, snake_case names, text case, spaces/characters, invalid values | 4 (`clean_sales_data()`) |
| 4 | New columns: total sales, profit margin %, discount amount, net sales, order month/year, profit category | 5 (`add_business_columns()`) |
| 5 | EDA: top 10 products/customers, region sales, category profit, monthly trend, average order value | 6 |
| 6 | Charts: line, bar, bar, horizontal bar, histogram (titles, axis labels, legends) | 7 |
| 7 | Business insights and 6 recommendations | PDF report |

## Key findings
- The input had already been through a first clean (Day 04): **0 missing values and 0 duplicates**. The pipeline still found and fixed hidden non-breaking spaces (225 product names), extra spaces (273 cells), text-typed dates and unneeded columns. Rules for nulls, duplicates and invalid values are built in and ran with zero hits.
- **West** is the highest-revenue region ($725K); **Technology** is the most profitable category ($145K, 17.4% margin).
- Discounts above 20% lose ~$135K; Furniture earns only a 2.5% margin.

## Method notes
- The data has no unit-price column, so `unit_price = sales / (quantity × (1 − discount))`. `total_sales` = quantity × unit_price (before discount), `net_sales` = total_sales − discount_amount (equals the source `sales`, asserted in code). "Sales" in the analysis means net sales.
- Profit category: High ≥ 30% margin, Medium 10–30%, Low < 10% (includes losses). Change `HIGH_MARGIN_PCT` / `MEDIUM_MARGIN_PCT` at the top of the script.
